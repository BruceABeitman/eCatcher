"""
APLIL is an apk(Android Application) instrumentation library.
"""
__author__ = 'Kun Yang'
__email__ = 'kelwya@gmail.com',
__copyright__ = 'Copyright 2012, The Honeynet Project'
__credits__ = ['Kun Yang']
__license__ = ''
__version__ = '0.1'

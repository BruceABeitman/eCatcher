## This file is supposed to be called from batch_plot.script with useArgs set to TRUE
## To execute this file inside R, set useArgs to FALSE
rm(list=ls())
source("plot_args.R")
useArgs <- FALSE

## args: options (1:actions, 2:sequences, 3:both), data_dir
args <- commandArgs(trailingOnly = TRUE)
home_dir <- getwd()

wd <- c()
plot_opt <- c()
if(useArgs == TRUE) {
  plot_opt <- args[1]
  wd <- args[2]
} else {
  print("Input plot option (0:non-interaction, 1:actions, 2:sequences, 3:all)")
  plot_opt <- scan(what=character(0), nmax=1)
  print("input data folder")
  wd <- scan(what=character(0), nmax=1)
}

## set up working directory
wd <- paste(home_dir, "/", wd, sep="")
setwd(wd)

package_name <- c()
print("Load package info")
load("package.Rdata")
print(paste("Targeted package:", package_name, sep=" "))

wd <- paste(wd, "/", package_name, sep="")
setwd(wd)
print(paste("Data folder:", wd, sep=" "))


## plotting function ##########################################################
## energy plot funciton
plot_action_energy <- function(m, save=FALSE, context=FALSE,
                               path=wd, out_name="plot_action_energy") {
  if(save == TRUE) {
    if(context == TRUE) {
      out_path <- paste(path, "/out_context", sep="")
    } else {
      out_path <- paste(path, "/out", sep="")
    }
    dir.create(out_path, showWarnings=FALSE)
    out_file <- paste(out_path, "/", out_name, ".eps", sep="")
    postscript(file=out_file, paper="letter", horizontal=TRUE)
  }

  ## m contains 4 lists: id, energy, label, duration
  med <- median(m$avg_energy)
  if(med > 0)
    m$avg_energy <- m$avg_energy/med

  ylim=c(min(m$avg_energy), min(10, max(m$avg_energy))) 
  #ylim=c(0, max(m$avg_energy))
  #boxplot(energy~id, m, main="", lwd=1.5, ylim=ylim)

  if(context == TRUE) {
    m$id <- m$context_id
  }

  idx = which(m$label == "N")
  if(length(idx) > 0) {
    plot(m$id[idx], m$avg_energy[idx], type="p", ylim=ylim,  
         pch=pch[1], lwd=1.5, cex.lab=1.2, cex.axis=0.45, 
         xlab="Action Unit", ylab="Normalized Average Energy Consumption")
    idx = which(m$label == "I")
    points(m$id[idx], m$avg_energy[idx], lwd=1.5, col="red", pch=pch[2])
  } else {
    idx = which(m$label == "I")
    plot(m$id[idx], m$avg_energy[idx], type="p", ylim=ylim, col="red", 
         pch=pch[2], lwd=1.5, cex.lab=1.2, cex.axis=0.45, 
         xlab="Action Unit", ylab="Normalized Average Energy Consumption")
  }

  if(save == TRUE) { 
    dev.off()
  }
    
  return(m)
}

## duration plot function
plot_action_duration <- function(m, save=FALSE, context=FALSE,
                                 path=wd, out_name="plot_action_duration") {
  if(save == TRUE) {
    if(context == TRUE) {
      out_path <- paste(path, "/out_context", sep="")
    } else {
      out_path <- paste(path, "/out", sep="")
    }
    dir.create(out_path, showWarnings=FALSE)
    out_file <- paste(out_path, "/", out_name, ".eps", sep="")
    postscript(file=out_file, paper="letter", horizontal=TRUE)
  }

  ## m contains 4 lists: id, energy, label, duration
  med <- median(m$duration)
  if(med > 0)
    m$duration <- m$duration/med

  #ylim=c(0, min(10, max(m$duration))) 
  ylim=c(min(m$duration), max(m$duration))
  #boxplot(duration~id, m, main="", lwd=1.5, ylim=ylim)
  
  if(context == TRUE) {
    m$id <- m$context_id
  }

  idx = which(m$label == "N")
  if(length(idx) > 0) {
    plot(m$id[idx], m$duration[idx], type="p", lwd=1.5, ylim=ylim,  pch=pch[1])
    idx = which(m$label == "I")
    points(m$id[idx], m$duration[idx], lwd=1.5, col="red", pch=pch[2])
  } else {
    idx = which(m$label == "I")
    plot(m$id[idx], m$duration[idx], type="p", lwd=1.5, ylim=ylim, col="red", pch=pch[2])
  }

  if(save == TRUE) { 
    dev.off()
  }
    
  return(m)
}

## plot function for actions
plot_actions <- function() {
  ## retrieve action files
  data_path <- paste(wd, "/actions", sep="")
  action_files <- list.files(path=data_path, pattern="^action_", 
                             full.names=TRUE, recursive=FALSE)
  action_avg_energy <- c()
  ret <- apply(as.array(action_files), 1, 
               function(x) {
                 load(x)
                 ## use average energy consumption instead of the absolute total value
                 ## By doing this, we can remove the effect caused by the length of the 
                 ## action, and have two separate attributes: average energy & duration.
                 ## The effect of the duration is: small power draw * long duration might
                 ## have the same value of large power draw * short duration. 
                 
                 ## ignore records with duration 0 if they happened rarely
                 effective_idx <- c(1:length(total_time))
                 if(length(which(total_time==0)) < length(total_time)/4) {
                   effective_idx <- which(total_time>0)
                 }
                
                 avg_energy <- total_energy/total_time
                 avg_energy[which(is.na(avg_energy))] <- 0
                 #m <- median(avg_energy)
                 ##m <- mean(avg_energy)
                 #if(m > 0)
                 #  avg_energy <- avg_energy/m

                 context_id <- paste(prev_id, action_id, next_id, sep="_")
                 energy_local <- cbind(action_id, avg_energy[effective_idx], 
                                       action_label[effective_idx], total_time[effective_idx], 
                                       log_name[effective_idx], context_id[effective_idx])
                 action_avg_energy <<- rbind(action_avg_energy, energy_local)

                 ## plot energy dist in an action
                 action_energy_local <- data.frame(id=as.factor(energy_local[,1]), 
                                                   avg_energy=as.numeric(energy_local[,2]),
                                                   label=energy_local[,3], 
                                                   duration=as.numeric(energy_local[,4]),
                                                   context_id=as.factor(energy_local[,6]))
                
                 out_name <- strsplit(basename(x), split=".Rdata")[[1]]
                 plot_action_energy(action_energy_local, save=TRUE, 
                                    path=data_path, out_name=paste(out_name, "energy", sep="_"))
                 #plot_action_duration(action_energy_local, save=TRUE, 
                 #                     path=data_path, out_name=paste(out_name, "duration", sep="_"))
               })

  action_energy <- data.frame(id=as.factor(action_avg_energy[,1]), 
                              avg_energy=as.numeric(action_avg_energy[,2]),
                              label=action_avg_energy[,3],
                              duration=as.numeric(action_avg_energy[,4]),
                              context_id=as.factor(action_avg_energy[,6]))

  plot_action_energy(action_energy, save=TRUE, path=data_path)
  plot_action_duration(action_energy, save=TRUE, path=data_path)
  plot_action_energy(action_energy, save=TRUE, path=data_path, context=TRUE)
  plot_action_duration(action_energy, save=TRUE, path=data_path, context=TRUE)
  
  return(ret)
}


## plot function for sequences
plot_sequences <- function() {
  ## retrieve sequence files
  data_path <- paste(wd, "/sequences", sep="")
  seq_files <- list.files(path=data_path, pattern="^seq_", 
                          full.names=TRUE, recursive=FALSE)
  sequence_energy <- c()
  ret <- apply(as.array(seq_files), 1, 
               function(x) {
                 load(x)
                 if(length(total_energy$seq_energy) > 0) {
                   #args <- unlist(total_energy$log_name)

                   ## plot
                   out_path <- paste(data_path, "/out", sep="")
                   dir.create(out_path, showWarnings=FALSE)
                   out_file <- paste(out_path, "/", 
                                     strsplit(basename(x), split=".Rdata")[[1]], ".eps", sep="")
                   postscript(file=out_file, paper="letter", horizontal=TRUE)

                   ## barplot
                   #h <- array(unlist(total_energy$seq_energy), 
                   #           dim=c(seq_len, length(total_energy$seq_energy)))
                   #ylim <- c(0, max(colSums(h)))
                   #m <- barplot(h, ylim=ylim)
                   #text(m, par("usr")[3]-1, srt=60, adj=1,
                   #     labels=args, xpd=TRUE, cex=0.8)

                   ## segments 
                   #ylim <- c(0, max(unlist(total_energy$seq_energy)))
                   ylim <- unlist(total_energy$seq_energy)/unlist(total_energy$seq_time)
                   ylim[which(is.na(ylim))] = 0
                   ylim <- c(0, max(ylim))
                   plot(c(1:length(total_energy$seq_energy[[1]])), 
                        total_energy$seq_energy[[1]], type="n", ylim=ylim)
                   for(i in 1:length(total_energy$seq_energy)) {
                     col <- ifelse(total_energy$seq_label[[i]]=="I", "red", "black")
                     #energy <- total_energy$seq_energy[[i]]
                     ## average energy consumption per action during a frequent sequence
                     energy <- total_energy$seq_energy[[i]]/total_energy$seq_time[[i]]
                     energy[which(is.na(energy))] = 0
                     points(c(1:length(energy)), energy,
                            pch=pch[i%%length(pch)], lwd=2.0, col=col)
                     if(length(energy) > 1) {
                       h <- embed(energy, dimension=2)
                       h_col <- embed(col, dimension=2)
                       col <- ifelse(h_col[,1]=="red" & h_col[,1]==h_col[,2], "red", "black")
                       segments(c(1:length(h[,1])), h[,2], 
                                c(1:length(h[,1]))+1, h[,1], 
                                lty=lty[i%%length(lty)], lwd=2.0, col=col)
                     }
                   }

                   dev.off()
                 }
               })

  return(ret)
}

## plot funciton for non-interaction energy
plot_non_int <- function() {
  data_path <- wd
  out_path <- paste(data_path, "/out", sep="")
  dir.create(out_path, showWarnings=FALSE)
  out_file <- paste(out_path, "/plot_non_int.eps", sep="")
  postscript(file=out_file, paper="letter", horizontal=TRUE)

  non_int_file <- paste(data_path, "/non_interaction.Rdata", sep="")
  load(non_int_file)

  ## lead_action_desc, duration, energy, display_use, label
  m <- data.frame(lead_action_desc, duration, energy, display_use, label)
  m$energy_avg <- m$energy/m$duration

  ylim=c(min(m$energy/m$duration), min(10, max(m$energy/m$duration))) 

  idx_n_disp_1 <- which(m$label=="N" & m$display_use==1)
  idx_n_disp_0 <- which(m$label=="N" & m$display_use==0)
  idx_i_disp_1 <- which(m$label=="I" & m$display_use==1)
  idx_i_disp_0 <- which(m$label=="I" & m$display_use==0)
  plot(as.factor(m$lead_action_desc[idx_n_disp_1]), m$energy_avg[idx_n_disp_1],
       type="p", lwd=1.5, ylim=ylim, pch=pch[1])
  points(as.factor(m$lead_action_desc[idx_n_disp_0]), m$energy_avg[idx_n_disp_0],
         lwd="1.5", col="blue", pch=pch[2])
  points(as.factor(m$lead_action_desc[idx_i_disp_1]), m$energy_avg[idx_i_disp_1],
         lwd="1.5", col="red", pch=pch[3])
  points(as.factor(m$lead_action_desc[idx_i_disp_0]), m$energy_avg[idx_i_disp_0],
         lwd="1.5", col="#FF6600", pch=pch[4])

  dev.off()
  return(m)
}


## plot clustering results 
plot_cluster <- function(m, save=FALSE,
                         path=wd, out_name="plot_action_cluster", ylab="") {
  if(save == TRUE) {
    out_path <- paste(path, "/out", sep="")
    dir.create(out_path, showWarnings=FALSE)
    out_file <- paste(out_path, "/", out_name, ".eps", sep="")
    postscript(file=out_file, paper="letter", horizontal=TRUE)
  }

  ## m contains 3 clummns: action, result, data size
  x <- strsplit(m[,1], "_")
  args <- unlist(lapply(x, function(x) x[2]))

  h <- as.numeric(m[,2])
  idx <- which(!is.na(h))
  
  barplot(h[idx], lwd=1.5, cex.lab=1.2, cex.axis=1.2, 
          names.arg=args[idx], cex.names=0.6, xlab="Action Unit", ylab=ylab)


  if(save == TRUE) { 
    dev.off()
  }
    
  return(m)
}



## end of plotting ############################################################
if(plot_opt == "0") {
  plot_non_int()
} else if(plot_opt == "1") {
  plot_actions()
} else if(plot_opt == "2") {
  plot_sequences()
} else if(plot_opt == "3") {
#  plot_non_int()
#  plot_actions()
#  plot_sequences()
} else {
  print("Error: unknow options")
}

setwd(home_dir)



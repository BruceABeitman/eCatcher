## This file is supposed to be called from batch_diagnosis.script with useArgs set to TRUE
## To execute this file inside R, set useArgs to FALSE
rm(list=ls())
useArgs <- TRUE

library(cluster)
library(class)
library("e1071", lib="/home/jychen/localx/r_packages")

## args: options (1:actions, 2:sequences, 3:both), data_dir
args <- commandArgs(trailingOnly = TRUE)
home_dir <- getwd()

wd <- c()
plot_opt <- c()
if(useArgs == TRUE) {
  plot_opt <- args[1]
  wd <- args[2]
} else {
  print("Input diagnosis option (1:action clustering only, 2:)")
  plot_opt <- scan(what=character(0), nmax=1)
  print("input data folder")
  wd <- scan(what=character(0), nmax=1)
}

## set up working directory
wd <- paste(home_dir, "/", wd, sep="")
setwd(wd)

package_name <- c()
print("Load package info")
load("package.Rdata")
print(paste("Targeted package:", package_name, sep=" "))

wd <- paste(wd, "/", package_name, sep="")
setwd(wd)
print(paste("Data folder:", wd, sep=" "))



## clustering with pam/kmeans
## label here is only used for verify the effectiveness of the clustering
## all the data used for clustering are supposed to be unlabeled
pam_clustering <- function(m, label=NULL, path=wd, out_name="pam_clus") {
  ## checking the best number of clusters
  ## this is only to make sure that cluster=2 could be always a proper choice
  ## we do not use this result to choose the number of clusters (at least for now)
  #out_path <- paste(path, "/clus_check", sep="")
  #dir.create(out_path, showWarnings=FALSE)
  #out_file <- paste(out_path, "/", out_name, "_check.eps", sep="")
  ## data_size should be at least larger than the # of clusters 
  ## we supposed that the length of m is larger than 2, and m is a dataframe
  data_size <- length(m[[1]])
  #postscript(file=out_file, paper="letter", horizontal=TRUE)
  #clus_list <- c(2:min(10, data_size-1))
  #y <- c()
  #for(i in clus_list) {
  #  #k <- kmeans(m, i, iter.max=500)
  #  #y <- c(y, k$tot.withinss)
  #  p <- pam(m, k=i)
  #  y <- c(y, p$silinfo$avg.width)
  #}
  #plot(clus_list, y, type="o", lwd=2)
  #dev.off()

  ## clustering 
  p <- pam(m, k=2)
  
  ## partition plot
  out_path <- paste(path, "/clus", sep="")
  dir.create(paste(out_path, "/out", sep=""), recursive=TRUE, showWarnings=FALSE)
  out_file <- paste(out_path, "/out/", out_name, ".eps", sep="")
  postscript(file=out_file, paper="letter", horizontal=TRUE)
  clusplot(p)
  dev.off()

  ## effectiveness calculation
  if(!is.null(label)) {
    m_label <- p$clustering
    if(table(p$clustering)[[1]] >= table(p$clustering)[[2]]) {
      m_label[which(p$clustering==1)] = "N"
      m_label[which(p$clustering==2)] = "I"
    } else {
      m_label[which(p$clustering==2)] = "N"
      m_label[which(p$clustering==1)] = "I"
    }

    m_l <- data.frame(m_label, label)    
    m_tp <- length(which(m_label=="I" & label=="I"))
    m_fp <- length(which(m_label=="I" & label=="N"))
    m_tn <- length(which(m_label=="N" & label=="N"))
    m_fn <- length(which(m_label=="N" & label=="I"))

    m_recall <- m_tp/(m_tp+m_fn)
    m_precision <- m_tp/(m_tp+m_fp)
    m_accuracy <- (m_tp+m_tn)/(m_tp+m_tn+m_fp+m_fn)
    m_false_alarm <- m_fp/(m_fp+m_tn)
    m_fscore <- 2*(m_precision*m_recall)/(m_precision+m_recall)
  
    clus_file <- paste(out_path, "/clus_res_", out_name, ".Rdata", sep="")
    save(m_l, m_tp, m_fp, m_tn, m_fn, m_recall, m_precision, m_accuracy, 
         m_false_alarm, m_fscore, data_size, out_name, file=clus_file)
  }

  return(m)
}

## action clustering
action_clustering <- function() {
  ## retrieve action files
  data_path <- paste(wd, "/actions", sep="")
  action_files <- list.files(path=data_path, pattern="^action_", 
                             full.names=TRUE, recursive=FALSE)
  
  ret <- apply(as.array(action_files), 1, 
               function(x) {
                 load(x)
                 ## use average energy consumption instead of the absolute total value
                 ## By doing this, we can remove the effect caused by the length of the 
                 ## action, and have two separate attributes: average energy & duration.
                 ## The effect of the duration is: small power draw * long duration might
                 ## have the same value of large power draw * short duration. 
                 avg_energy <- total_energy/total_time
                 avg_energy[which(is.na(avg_energy))]=0
                 m <- data.frame(avg_energy)
                 #m <- data.frame(avg_energy, prev_id, next_id)

                 out_name <- strsplit(basename(x), split=".Rdata")[[1]]
                 print(out_name)
                 print(m)
                 ## the number of data should be larger than the # of clusters
                 if(length(m[[1]]) > 2) {
                   pam_clustering(m, label=action_label,
                                  path=data_path, out_name=paste(out_name, "clus", sep="_"))
                 } else {
                   print(paste("Warning:", out_name, 
                               "is ignored because length is smaller than 2", sep=" "))
                 }
               })

  ## result analysis
  data_path <- paste(wd, "/actions/clus", sep="")
  clus_files <- list.files(path=data_path, pattern="^clus_res_", 
                           full.names=TRUE, recursive=FALSE)

  action_recall <- c()
  action_accuracy <- c()
  action_precision <- c()
  action_false_alarm <- c()
  action_fscore <- c()
  ret <- apply(as.array(clus_files), 1, 
               function(x) {
                 load(x)
                 action_recall <<- rbind(action_recall, cbind(out_name, m_recall, data_size))
                 action_accuracy <<- rbind(action_accuracy, cbind(out_name, m_accuracy, data_size))
                 action_precision <<- rbind(action_precision, cbind(out_name, m_precision, data_size))
                 action_false_alarm <<- rbind(action_false_alarm, cbind(out_name, m_false_alarm, data_size))
                 action_fscore <<- rbind(action_fscore, cbind(out_name, m_fscore, data_size))
               })
  rownames(action_recall) <- NULL
  rownames(action_accuracy) <- NULL
  rownames(action_precision) <- NULL
  rownames(action_false_alarm) <- NULL
  rownames(action_fscore) <- NULL

  out_file <- paste(data_path, "/clus_res.Rdata", sep="")
  save(action_recall, action_accuracy, action_precision, 
       action_false_alarm, action_fscore, file=out_file)  
  
  #out_file <- paste(data_path, "/action_recall.eps", sep="")
  #postscript(file=out_file, paper="letter", horizontal=TRUE)
  #plot(p)
  #dev.off()
  
  return(ret)
}

### action analaysis
#data_folder<- "k9_2403_0304+0318"
#package_name <- "com.fsck.k9"
#action_file <- "action_27_27_28.Rdata"
#load(paste(data_folder, "/", package_name, "/actions/", action_file, sep=""))
#
#power_avg <- total_energy[which(total_time>0)]/total_time[which(total_time>0)]
##m <- data.frame(scale(power_avg), prev_id, next_id)
#m <- data.frame(scale(power_avg))
#p <- pam(m, k=2)
#
#c1 <- rownames(p$silinfo$width)[which(p$silinfo$width[,1]==1 & p$silinfo$width[,3]>=0.8)]
#c2 <- rownames(p$silinfo$width)[which(p$silinfo$width[,1]==2 & p$silinfo$width[,3]>=0.8)]
#m_l <- cbind(m[as.numeric(c1)], "1")
#m_l <- rbind(m_l, cbind(m[as.numeric(c2)], "2"))
#c0 <- rownames(p$silinfo$width)[which(p$silinfo$width[,3]<0.8)]
#m_u <- cbind(m[as.numeric(c0)])
#
#model <- naiveBayes(m_l[,1], as.factor(m_l[,2]))
#table(predict(model, m_u[,1]))

## sequence analysis
#data_folder<- "k9_2403_0304+0318"
#package_name <- "com.fsck.k9"
#seq_file <- "seq_38.Rdata"
#
#load(paste(data_folder, "/", package_name, "/sequences/", seq_file, sep=""))
### using per-action total energy consumption in a sequence as the dataset
#m1 <- matrix(unlist(total_energy$seq_energy), ncol=seq_len)
#t1 <- matrix(unlist(total_energy$seq_time), ncol=seq_len)
#m1 <- rowSums(m1)/rowSums(t1)

## using per-action average energy consumption in a sequence as the dataset
#m2 <- unlist(total_energy$seq_energy)/unlist(total_energy$seq_time)
#m2[which(is.na(m2))] <- 0
#m2 <- matrix(m2, ncol=seq_len)
#
#m <- cbind(m1, m2)

#p <- pam(m1, 2)


## end of plotting ############################################################
if(plot_opt == "1") {
  action_clustering()
} else if(plot_opt == "2") {
} else if(plot_opt == "3") {
} else {
  print("Error: unknow options")
}

setwd(home_dir)


## line style
## 0=blank, 1=solid, 2=dashed, 3=dotted, 4=dotdash, 5=longdash, 6=twodash
lty <- c(1:6);

## points style
## 1=circle, 0=square, 2=triangle up, 3=plus, 4=cross, 5=diamond, 6=triangle down, 8=star 
pch = c(1, 2, 0, 3, 4, 8, 5, 6)

